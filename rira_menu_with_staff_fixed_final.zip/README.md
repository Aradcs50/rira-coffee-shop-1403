
  # Rira coffee menu (Community) (Copy)

  This is a code bundle for Rira coffee menu (Community) (Copy). The original project is available at https://www.figma.com/design/WRLDQvIKF9uiGKt2H3ED7V/Rira-coffee-menu--Community---Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  